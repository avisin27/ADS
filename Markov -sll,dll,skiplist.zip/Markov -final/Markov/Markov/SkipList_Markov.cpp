#include "SkipList_Markov.h"
#include <string>
#include <iostream>


template class Skiplist_Markov<std::string>;
template <typename T>

Node<T> **Skiplist_Markov<T>::find(T t, Node<T> **first) {
	if (!head)
		return 0; 

	// start search with first node
	Node<T> *current = head;
	int levelCount = current->next.getLength();

	// the array of nodes to return.
	Node<T> **results = new Node<T> *[levelCount];

	for (int current_level = levelCount - 1; current_level != -1; --current_level) {

		while (current->next.getValue(current_level) && t >= current->next.getValue(current_level)->info)
	
			current = current->next.getValue(current_level);
		results[current_level] = current;
	}

	if (first)
		*first = results[0];
	return results;
}

template <typename T>

Node<T> *Skiplist_Markov<T>::add(T t) {

	Node<T> **lefts = find(t);

	if (!lefts)
	{
		head = new Node<T>(t);
		head->next.push(0);
		return head;
	}

	if (lefts[0]->info == t)
	{
		Node<T> *r = lefts[0];
		delete[] lefts; 
		return r;
	}
		
	unsigned newLevel = 0;
	while (rand() % 2)
		++newLevel;

	Node<T> *newNode = new Node<T>(t);
	for (unsigned l = 0; l <= newLevel; ++l)
	{

		if (l < head->next.getLength()) {
			newNode->next.push(lefts[l]->next.getValue(l));
			lefts[l]->next.getValue(l) = newNode;
		}
		else {
			// new node is higher than maximum, so increment maximum
			// since newnode is the only node at this level, its next node at this level always is zero.
			newNode->next.push(0);
			head->next.push(newNode);
		}

	}

	delete[] lefts;
	return newNode;
}

template <class T>
unsigned Skiplist_Markov<T>::countNodes() {
	unsigned count = 0;
	for (Node<T> *current = head; current; current = current->next.getValue(0))
		++count;
	return count;
}

template <class T>
Node<T> *Skiplist_Markov<T>::getNode(unsigned i) {
	Node<T> *current;
	for (current = head; current && i; --i)
		current = current->next.getValue(0);
	return current;
}

template <typename T>
T Skiplist_Markov<T>::generate(int n) {
	T inc;
	Node<T> *current = getNode(rand() % countNodes());
	T succ = current->info;
	for (int i = 0; i < n && current->info == succ; ++i)
	{
		inc += ' ';
		inc += succ;

		succ = current->getRandom();
		// store the found node at "current"
		delete[] find(succ, &current);
	}
	return inc;
}


template <typename T>
void Skiplist_Markov<T>::add(T t1, T t2) {
	Node<T> *n1 = add(t1);
	// add t2 as a successor word for n1
	n1->v.push(t2);
}