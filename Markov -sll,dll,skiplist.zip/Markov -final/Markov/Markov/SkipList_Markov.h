#ifndef SKIPLIST_MARKOV_H_INCLUDED
#define SKIPLIST_MARKOV_H_INCLUDED

#include "Vector.h"
#include "stdlib.h"
#include "IMarkov.h"


template <typename T>
struct Node { 
	Node(T t): info(t) {}

	// all successor words as strings
	CustomVector<T> v;    
	T info;

	CustomVector<Node<T> *> next;

	// just like DLL_Markov_Node::getRandom()
	T getRandom() {
		return v.getValue(rand() % v.getLength());
	}
};

template<class T> 
class Skiplist_Markov : public IMarkov<T> { 
public:     
	// set head to zero: no nodes.
	Skiplist_Markov(): head(0) {}

	T generate(int i);     
	void add(T t1, T t2); 

	Node<T> **find(T t, Node<T> **first = 0);
	Node<T> *add(T t);
	Node<T> *getNode(unsigned i);

	~Skiplist_Markov() {
		Node<T> *next;
		for (Node<T> *current = head; current; current = next)
		{
			next = current->next.getValue(0);
			delete current;
		}
			
	}

private:
	unsigned countNodes();

	// pointer to first node of this list
	// or zero if the list is empty
	Node<T> *head;
};

#endif