
#ifndef ML_MARKOV_H_INCLUDED
#define ML_MARKOV_H_INCLUDED

#include "IMarkov.h"
#include "Vector.h"

template <class T>
class ML_Markov_Node {
public:
	ML_Markov_Node(T t): next(0), prev(0), info(t) {}

	// get a random successor node
	ML_Markov_Node<T> *getRandom();
	void addNew(ML_Markov_Node<T> *n);

    T info;
	// store pointers, not strings.
	CustomVector<ML_Markov_Node<T> *> v;
    ML_Markov_Node<T> *next, *prev;
};

template <class T>
class ML_Markov : public IMarkov<T> {
public:
	ML_Markov(): head(0), tail(0) {}
	~ML_Markov();

    void add(T t1, T t2);
    T generate(int);
public:
    ML_Markov_Node<T> *addNode(T t1);
    ML_Markov_Node<T> *find(T t1);
	unsigned countNodes();
	ML_Markov_Node<T> *getNode(unsigned);

    ML_Markov_Node<T> *head, *tail;
};


#endif
