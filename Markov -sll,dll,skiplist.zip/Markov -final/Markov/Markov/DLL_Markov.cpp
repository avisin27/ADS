#include "DLL_Markov.h"
#include <stdlib.h>
#include <string>
#include <iostream>

template class DLL_Markov<std::string>;
template <class T>
T DLL_Markov_Node<T>::getRandom() {
	if (v.getLength() == 0) 
		return T(); // then return an empty word
        return v.getValue(rand() % v.getLength()); 
}

template <class T>
void DLL_Markov_Node<T>::addNew(T t) {
	// add t to the list of successors
    v.push(t);
}

template <class T>
DLL_Markov_Node<T> *DLL_Markov<T>::addNode(T t1) {
	DLL_Markov_Node<T> *newNode = new DLL_Markov_Node<T>(t1);
    newNode->next = 0;
    newNode->prev = tail;
    tail = newNode;

    if (newNode->prev)
        newNode->prev->next = newNode;
    else 
        head = newNode; 
    return tail;
}

template <class T>
DLL_Markov<T>::~DLL_Markov() {
	for (DLL_Markov_Node<T> *current = head; current; current = current->next)
		delete current;
}

template <class T>
// find the node that stores the word t1
DLL_Markov_Node<T> *DLL_Markov<T>::find(T t1)
{
    DLL_Markov_Node<T> *n1 = 0;
	// start at the first node, pointed by head
    DLL_Markov_Node<T> *current = head;
    while (current && !n1) {
        if (current->info == t1)
            n1 = current;
        current = current->next;
    }

    return n1;
}

template <class T>
void DLL_Markov<T>::add(T t1, T t2) {
    DLL_Markov_Node<T> *n1 = find(t1);
    if (!n1)
        n1 = addNode(t1);
    n1->addNew(t2);
}

template <class T>
unsigned DLL_Markov<T>::countNodes() {
	// start with a count of zero. this variable will be incremented in the loop below
	unsigned count = 0;
	for (DLL_Markov_Node<T> *current = head; current; current = current->next)
		++count;
	return count;
}

template <class T>
// get the node in this list at index i
DLL_Markov_Node<T> *DLL_Markov<T>::getNode(unsigned i) {
	DLL_Markov_Node<T> *current;
	for (current = head; current && i; --i)
		current = current->next;
	return current;
}

template <class T>
T DLL_Markov<T>::generate(int n) {
	// the "sentence" that we are generating
	T inc;
	DLL_Markov_Node<T> *current = getNode(rand() % countNodes());

	for (int i = 1; i < n && current; ++i)
	{
		inc += ' ';
		// add current word
		inc += current->info;
		current = find(current->getRandom());
	}
		
	return inc;
}
