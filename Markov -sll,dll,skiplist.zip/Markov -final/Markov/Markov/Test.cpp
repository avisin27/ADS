
#include "SkipList_Markov.h"
#include "DLL_Markov.h"
#include "ML_Markov.h"
#include "Vector.h"
#include <iostream>
#include <string>
#include <fstream>
#include <ctime>

using std::string;

void split(const std::string &s, char delim, CustomVector<std::string> &elems) {
	std::string temp;  
	for (size_t i = 0; i < s.size(); i++)
	{   
		if (s.at(i) != delim) { 
			temp.append(s, i, 1);    
			if (i == s.size() - 1)     
				elems.push(temp); 
		}
		else if (temp != "") { 
			elems.push(temp);    
			temp = ""; 
		}  
	}
} 


void test_markov(IMarkov<std::string> *markov) {
	srand((unsigned)time(0));  

	// load test file
	std::ifstream file("text.txt");  
	std::string str;  

	// contains all the words.
	CustomVector<std::string> elems;  
	while (std::getline(file, str)) { 
		split(str, ' ', elems); 
	}  

	// iterate through every single word in elems
	for (unsigned i = 0; i < elems.getLength() - 1; ++i) { 
		markov->add(elems.getValue(i), elems.getValue(i + 1));
	}  
	
	std::cout << markov->generate(30) << "\n\n";
}

int main() {

	std::cout << "/n Implementation of Doubly Linked List";
	test_markov(new DLL_Markov<std::string>());
	std::cout << "/n Implementation of Multi Linked List";
    test_markov(new ML_Markov<std::string>());
	std::cout << "/n Implementation of Skiplist";
	test_markov(new Skiplist_Markov<std::string>());

	std::getline(std::cin, std::string());
}
