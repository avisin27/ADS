#ifndef DLL_MARKOV_H_INCLUDED
#define DLL_MARKOV_H_INCLUDED

#include "IMarkov.h"
#include "Vector.h"

template <class T>
class DLL_Markov_Node {
public:
	
	DLL_Markov_Node(T t): next(0), prev(0), info(t) {}

	T getRandom();
	void addNew(T t);
    T info;
    CustomVector<T> v;
    DLL_Markov_Node<T> *next, *prev;
};

// implementation of the abstract IMarkov class
// contains a doubly linked list, containing DLL_Markov_Node
template <class T>
class DLL_Markov : public IMarkov<T> {
public:

	// set the head and tail to zero at first
	 DLL_Markov(): head(0), tail(0) {}
	~DLL_Markov();

    void add(T t1, T t2);
    T generate(int n);
public:
    DLL_Markov_Node<T> *addNode(T t1);
    DLL_Markov_Node<T> *find(T t1);
	unsigned countNodes();
	DLL_Markov_Node<T> *getNode(unsigned i);

	// the first and last node in this list
    DLL_Markov_Node<T> *head, *tail;
};


#endif
