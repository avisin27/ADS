
#ifndef VECTOR_H_INCLUDED
#define VECTOR_H_INCLUDED

template <typename T>
class CustomVector
{
public:
	CustomVector();
	~CustomVector();

	void push(T);
	T &getValue(unsigned);
    unsigned getLength() {return len;}

private:
	T* arr;
	unsigned len;
	unsigned cap;
};

template <typename T>
CustomVector<T>::CustomVector()
{
	len = 0;
	cap = 0;
	arr = 0;
}

template <typename T>
CustomVector<T>::~CustomVector()
{
	if (arr)
		delete[] arr;
}

template <typename T>
void CustomVector<T>::push(T val)
{
	if (len < cap)
	{
		arr[len++] = val;
	}

	else
	{
		cap += cap + 1;
		T* temp = new T[cap];

		for (unsigned i = 0; i < len; ++i)
			temp[i] = arr[i];

		temp[len] = val;

		++len;

		if (arr)
			delete[] arr;
		arr = temp;
	}
}

template <typename T>
T &CustomVector<T>::getValue(unsigned index)
{
	return arr[index];
}


#endif
