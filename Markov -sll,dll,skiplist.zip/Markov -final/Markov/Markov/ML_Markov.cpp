#include "ML_Markov.h"
#include <stdlib.h>
#include <string>

template class ML_Markov<std::string>;

template <class T>
ML_Markov_Node<T> *ML_Markov_Node<T>::getRandom() {
	if (v.getLength() == 0)
		return 0;
    return v.getValue(rand() % v.getLength());
}

template <class T>
void ML_Markov_Node<T>::addNew(ML_Markov_Node<T> *n) {
    v.push(n);
}

template <class T>
ML_Markov_Node<T> *ML_Markov<T>::addNode(T t1) {
    ML_Markov_Node<T> *newNode = new ML_Markov_Node<T>(t1);
    newNode->next = 0;
    newNode->prev = tail;
    tail = newNode;
    if (newNode->prev)
        newNode->prev->next = newNode;
    else
        head = newNode;
    return tail;
}

template <class T>
ML_Markov<T>::~ML_Markov() {
	for (ML_Markov_Node<T> *current = head; current; current = current->next)
		delete current;
}

template <class T>
ML_Markov_Node<T> *ML_Markov<T>::find(T t1)
{
    ML_Markov_Node<T> *n1 = 0;

    ML_Markov_Node<T> *current = head;
    while (current && !n1) {
        if (current->info == t1)
            n1 = current;
        current = current->next;
    }

    return n1;
}

template <class T>
void ML_Markov<T>::add(T t1, T t2) {
    ML_Markov_Node<T> *n1 = find(t1);
    if (!n1)
        n1 = addNode(t1);
	
	ML_Markov_Node<T> *n2 = find(t2);
	if (!n2)
		n2 = addNode(t2);

    n1->addNew(n2);
}

template <class T>
unsigned ML_Markov<T>::countNodes() {
	unsigned count = 0;
	for (ML_Markov_Node<T> *current = head; current; current = current->next)
		++count;
	return count;
}

template <class T>
ML_Markov_Node<T> *ML_Markov<T>::getNode(unsigned i) {
	ML_Markov_Node<T> *current;
	for (current = head; current && i; --i)
		current = current->next;
	return current;
}

template <class T>
T ML_Markov<T>::generate(int n) {
	T inc;

	ML_Markov_Node<T> *current = getNode(rand() % countNodes());
	for (int i = 1; i < n && current; ++i)
	{
		inc += ' ';
		inc += current->info;
		current = current->getRandom();
	}

	return inc;
}
