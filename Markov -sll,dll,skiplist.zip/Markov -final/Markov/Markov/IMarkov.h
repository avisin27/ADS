#ifndef IMARKOV_H_INCLUDED
#define IMARKOV_H_INCLUDED

// Base class for all implementations of Markov
template <class T>
class IMarkov {
public:
    virtual void add(T, T) = 0;
    virtual T generate(int) = 0;
    virtual ~IMarkov() {}
};

#endif
